package ru.optimus.test.commands;

import org.bukkit.command.CommandSender;
import ru.optimus.commands.annotations.AsCommand;
import ru.optimus.commands.annotations.Description;
import ru.optimus.commands.annotations.Messages;
import ru.optimus.commands.annotations.logging.Logging;
import ru.optimus.commands.executes.AbstractCommand;


@AsCommand(name = "test", permission = "test:use", aliases = {"t", "x", "xyi"}, onlyPlayer = false)
@Messages(onlyPlayer = "Only player frik!", exceptionMessage = "/test")
@Logging(path = "plugins/test/log.txt")
@Description(message = "send xyi")
public class Com extends AbstractCommand {

  @Override
  public boolean onCommand(CommandSender sender, String[] args) {

    return true;
  }
}

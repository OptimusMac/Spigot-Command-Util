package ru.optimus.test;

import lombok.Getter;
import org.bukkit.plugin.java.JavaPlugin;
import ru.optimus.commands.asm.ClassFinder;
import ru.optimus.commands.asm.managers.ManagerAdapter;

public class Main extends JavaPlugin {

  @Getter
  private static Main instance;


  @Override
  public void onEnable() {
    instance = this;
    saveDefaultConfig();
    ManagerAdapter.addAdapter(this, new ClassFinder("ru.optimus.test.commands", this)).register();
  }

}
